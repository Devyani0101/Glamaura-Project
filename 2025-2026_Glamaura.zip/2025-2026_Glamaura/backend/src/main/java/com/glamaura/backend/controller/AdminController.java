package com.glamaura.backend.controller;

import com.glamaura.backend.entity.Order;
import com.glamaura.backend.repository.OrderRepository;
import com.glamaura.backend.repository.ProductRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;



@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderRepository orderRepository;

    
    
    
    @GetMapping("/dashboard")
    public String dashboard(Model model,HttpSession session) {
        String role=(String)session.getAttribute("role");
       if(role == null || !role.equalsIgnoreCase("ADMIN")){
           return "redirect:/index";
       }
       
        long totalProducts = productRepository.count();
        long totalOrders = orderRepository.count();
        long pendingOrders = orderRepository.countByStatus("Pending");
      

        model.addAttribute("totalProducts", totalProducts);
        model.addAttribute("totalOrders", totalOrders);
                 model.addAttribute("pendingOrders", pendingOrders);

        return "admin/dashboard";
    }

    
    
   
    @GetMapping("/products")
    public String manageProducts(Model model,HttpSession session) {
        String role=(String)
                session.getAttribute("role");
        if(role==null || !role.equalsIgnoreCase("ADMIN")){
            return "redirect:/index";
        }
        model.addAttribute("products", productRepository.findAll());
        return "admin/manage-products";
    }

    
   
    
    @GetMapping("/delete-product/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productRepository.deleteById(id);
        return "redirect:/admin/products";
    }

   
    
    
    @GetMapping("/orders")
    public String manageOrders(Model model,HttpSession session) {
        String role=(String)
                session.getAttribute("role");
        if(role==null || !role.equalsIgnoreCase("ADMIN")){
            return "redirect:/index";
        }
        model.addAttribute("orders", orderRepository.findAll());
        return "admin/manage-orders";
    }
        
  @GetMapping("/order-confirm/{id}")
public String confirmOrder(@PathVariable Long id) {

    Order order = orderRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Order not found"));

    order.setStatus("Confirmed");

    orderRepository.save(order);

    return "redirect:/admin/orders";
}

@GetMapping("/order-deliver/{id}")
public String deliverOrder(@PathVariable Long id) {

    Order order = orderRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Order not found"));

    order.setStatus("Delivered");

    orderRepository.save(order);

    return "redirect:/admin/orders";
}

@GetMapping("/order-delete/{id}")
public String deleteOrder(@PathVariable Long id) {
    orderRepository.deleteById(id);
    return "redirect:/admin/orders";
}
   }
