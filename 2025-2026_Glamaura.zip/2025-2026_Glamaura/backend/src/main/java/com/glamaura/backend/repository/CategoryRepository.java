package com.glamaura.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.glamaura.backend.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}