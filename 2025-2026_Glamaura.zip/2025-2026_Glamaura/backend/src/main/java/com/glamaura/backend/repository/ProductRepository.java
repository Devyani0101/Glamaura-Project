    package com.glamaura.backend.repository;
    import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.glamaura.backend.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategoryId( Long id);
    
    List<Product> findByNameContainingIgnoreCase(String keyword);

    

    

    

    
}
