package com.glamaura.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.glamaura.backend.entity.Order;
import com.glamaura.backend.entity.Product;
import com.glamaura.backend.repository.OrderRepository;
import com.glamaura.backend.repository.ProductRepository;

@Controller
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

   
    @PostMapping("/order-now")
    public String orderNow(@RequestParam Long productId, Model model) {

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        model.addAttribute("product", product);

        return "order-now";
    }


    
    @PostMapping("/order-review")
    public String orderReviewPage(
            @RequestParam Long productId,
            @RequestParam String username,
            @RequestParam String mobile,
            @RequestParam String address,
            @RequestParam int quantity,
             
            Model model) {

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        double totalAmount = 
                 (product.getPrice() * quantity);
        model.addAttribute("product", product);
        model.addAttribute("username", username);
        model.addAttribute("mobile", mobile);
        model.addAttribute("address", address);
        model.addAttribute("quantity", quantity);
        model.addAttribute("totalAmount",totalAmount);
        
        return "order-review";
    }


    
    @PostMapping("/payment")
public String paymentPage(
        @RequestParam Long productId,
        @RequestParam String username,
        @RequestParam String mobile,
        @RequestParam String address,
        @RequestParam int quantity,
        @RequestParam double totalAmount,
        Model model
) {
    Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));

    model.addAttribute("product", product);
    model.addAttribute("username", username);
    model.addAttribute("mobile", mobile);
    model.addAttribute("address", address);
    model.addAttribute("quantity", quantity);
    model.addAttribute("totalAmount", totalAmount);

    return "payment"; }


    
    @PostMapping("/success")
    public String saveOrder(
            @RequestParam Long productId,
            @RequestParam String username,
            @RequestParam String mobile,
            @RequestParam String address,
            @RequestParam String paymentMode,
            @RequestParam int quantity,
            Model model){
    Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));
    
        if (paymentMode.equals("ONLINE")) {
    model.addAttribute("productId", productId);
    model.addAttribute("username", username);
    model.addAttribute("mobile", mobile);
    model.addAttribute("address", address);
    model.addAttribute("quantity", quantity);
    return "online-payment";
}

        
        Order order = new Order();
        order.setProduct(product.getName());
        order.setPrice(product.getPrice());
        order.setQuantity(quantity);
        
       
        
        
         double totalAmount = 
                 (product.getPrice() * quantity);
         
        order.setTotalAmount(totalAmount);
        order.setUsername(username);
        order.setMobile(mobile);
        order.setAddress(address);
        order.setPaymentMode("COD");
        
       
        order.setStatus("Pending");

        orderRepository.save(order);

       

        return "redirect:/success";
    }
    
    @PostMapping("/final-success")
    public String onlinePaymentSuccess(
            @RequestParam Long productId,
            @RequestParam String username,
            @RequestParam String mobile,
            @RequestParam String address,
            @RequestParam int quantity) {

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Order order = new Order();
        order.setProduct(product.getName());
        order.setPrice(product.getPrice());
        order.setQuantity(quantity);

        double totalAmount = product.getPrice() * quantity;

        order.setTotalAmount(totalAmount);
        order.setUsername(username);
        order.setMobile(mobile);
        order.setAddress(address);
        order.setPaymentMode("ONLINE");

        order.setStatus("Pending");

        orderRepository.save(order);

        return "success";
    }
    
    @GetMapping("/success")
    public String successPage(){
        return "success";
        
    }
    
@GetMapping("/admin/confirm/{id}")
public String confirmOrder(@PathVariable Long id) {
    Order order = orderRepository.findById(id).get();
    order.setStatus("Confirmed");
    orderRepository.save(order);
    return "redirect:/manage-orders";
}


@GetMapping("/admin/deliver/{id}")
public String deliverOrder(@PathVariable Long id) {
    Order order = orderRepository.findById(id).get();
    order.setStatus("Delivered");
    orderRepository.save(order);
    return "redirect:/manage-orders";
}

@GetMapping("/admin/delete/{id}")
public String deleteOrder(@PathVariable Long id) {
    orderRepository.deleteById(id);
    return "redirect:/manage-orders";
}

}