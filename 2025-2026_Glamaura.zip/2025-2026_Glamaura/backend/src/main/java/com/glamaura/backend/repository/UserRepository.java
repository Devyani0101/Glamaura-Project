package com.glamaura.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.glamaura.backend.entity.User;
import org.springframework.stereotype.Repository;

@Repository

public interface UserRepository extends JpaRepository<User, Long> {
    User findByname(String name);
     User findByEmail(String email);
}
