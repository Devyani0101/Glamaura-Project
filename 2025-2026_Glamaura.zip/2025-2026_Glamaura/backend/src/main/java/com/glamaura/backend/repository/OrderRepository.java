package com.glamaura.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.glamaura.backend.entity.Order;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    
    long countByStatus(String status);
    List<Order> findByUsername(String username);
}