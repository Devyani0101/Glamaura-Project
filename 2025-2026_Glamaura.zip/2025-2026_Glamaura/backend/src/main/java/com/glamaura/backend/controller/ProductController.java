package com.glamaura.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.glamaura.backend.entity.Product;
import com.glamaura.backend.repository.ProductRepository;
import jakarta.servlet.http.HttpSession;

@Controller
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    
    @GetMapping("/products")
    public String allProducts(Model model) {
        List<Product> products = productRepository.findAll();
        System.out.println("products");
        model.addAttribute("products", products);
        return "products";   
    }

    @GetMapping("/product/{id}")
public String productDetail(@PathVariable Long id, Model model) {
    Product product = productRepository.findById(id).orElse(null);
    model.addAttribute("product", product);
    return "product-detail";
}
    
    
    @GetMapping("products/categories/{id}")
    public String productByCategory(@PathVariable Long id, Model model) {
        List<Product> products = productRepository.findByCategoryId(id); 
        model.addAttribute("products", products);
        return "products";
    }

    
    @PostMapping("/products/add")
public String addProducts(@ModelAttribute Product product, HttpSession session) {

    String role = (String) session.getAttribute("role");

    // ❌ USER BLOCK
    if(role == null || !role.equalsIgnoreCase("ADMIN")){
        return "redirect:/products";
    }

    // ✅ ADMIN ALLOWED
    productRepository.save(product);

    return "redirect:/products";
}

@GetMapping("/products/delete/{id}")
public String deleteProduct(@PathVariable Long id, HttpSession session) {

    String role = (String) session.getAttribute("role");

    // ❌ USER BLOCK
    if(role == null || !role.equalsIgnoreCase("ADMIN")){
        return "redirect:/products";
    }

    // ✅ DELETE
    productRepository.deleteById(id);

    return "redirect:/products";
}

    @GetMapping("/api/products")
    @ResponseBody
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
    
    @GetMapping("/search")
public String searchProduct(@RequestParam("keyword") String keyword, Model model) {
    List<Product> products = productRepository.findByNameContainingIgnoreCase(keyword);
    model.addAttribute("products", products);
    return "products"; 
}
}