package com.glamaura.backend.controller;
import com.glamaura.backend.entity.Order;
import com.glamaura.backend.entity.User;
import com.glamaura.backend.repository.OrderRepository;
import com.glamaura.backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private OrderRepository orderRepository;

    
    @GetMapping("/signup")
    public String signupForm() {
        return "signup"; }

    
@PostMapping("/signup")
public String signupSubmit(@RequestParam String name,
                           @RequestParam String email,
                           @RequestParam String password,
                           HttpSession session) {

    User user = new User();

    user.setName(name);
    user.setEmail(email);
    user.setPassword(password);

    
    user.setRole("USER");

    userRepository.save(user);
    session.setAttribute("userId", user.getId());
    session.setAttribute("role", user.getRole());

    

    return "redirect:/index";
}
    
    @GetMapping("/login")
    public String loginForm() { return "login"; }

    
    @PostMapping("/login")
    public String loginSubmit(@RequestParam String email,
                              @RequestParam String password,
                              Model model,HttpSession session) {

     
    User user = userRepository.findByEmail(email);

    if (user != null && user.getPassword().equals(password)) {
       
        session.setAttribute("userId", user.getId());
        session.setAttribute("role", user.getRole());
        
        if("ADMIN".equalsIgnoreCase(user.getRole())){
            return "redirect:/admin/dashboard";
        }
        return"redirect:/index";
        
    }

    model.addAttribute("error", "Invalid email or password");
    return "login";
}

    
    @GetMapping("/forgot-password")
    public String forgotPasswordForm() { return "forgot-password"; }

    
    @PostMapping("/forgot-password")
    public String forgotPasswordSubmit(@RequestParam String email,
                                       @RequestParam String newPassword,
                                       Model model) {

        User user = userRepository.findByEmail(email);
        if(user == null){
            model.addAttribute("error", "Email not registered!");
            return "forgot-password";
        }

        user.setPassword(newPassword);
        userRepository.save(user);

        model.addAttribute("success", "Password reset successfully! Please login.");
        return "login";
    }
    @GetMapping("/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:/index";
        
    }
    
    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {

        Long userId = (Long) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");

        if(userId == null){
            return "redirect:/login";
        }

        if(role != null && role.equalsIgnoreCase("ADMIN")){
            return "redirect:/admin/dashboard";
        }

        User user = userRepository.findById(userId).orElse(null);

        if(user==null)
        {
            return"redirect:/login";
        }
        model.addAttribute("user", user);

        List<Order> orders = orderRepository.findByUsername(user.getName());
    model.addAttribute("orders", orders);
    
        return "profile";
    }

    
        }
   
