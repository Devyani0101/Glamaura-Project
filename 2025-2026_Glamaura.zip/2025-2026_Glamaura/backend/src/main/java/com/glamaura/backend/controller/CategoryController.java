package com.glamaura.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.glamaura.backend.entity.Category;
import com.glamaura.backend.entity.Product;
import com.glamaura.backend.repository.CategoryRepository;
import com.glamaura.backend.repository.ProductRepository;

@Controller
public class CategoryController {

    @Autowired
    private CategoryRepository categoryRepo;

    @Autowired
    private ProductRepository productRepo;

    
    @GetMapping("/categories")
    public String showCategories(Model model) {

        List<Category> list = categoryRepo.findAll();
        model.addAttribute("categories", list);

        return "categories";   
    }

    
    @GetMapping("/category/{id}")
    public String productsByCategory(@PathVariable("id") Long id, Model model) {

        List<Product> products = productRepo.findByCategoryId(id);
        model.addAttribute("products", products);
        
        model.addAttribute("hideAddProduct",true);

        return "products";   
    }
}