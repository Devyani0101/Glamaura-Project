package com.glamaura.backend.controller;


import java.util.List;


import com.glamaura.backend.entity.Cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.glamaura.backend.entity.Product;
import com.glamaura.backend.repository.ProductRepository;
import org.springframework.web.bind.annotation.RequestParam;
import com.glamaura.backend.entity.Order;
import com.glamaura.backend.repository.OrderRepository;
import com.glamaura.backend.repository.CartRepository;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
@RequestMapping("/cart")
public class CartController {
    @Autowired
    ProductRepository productRepository;
    
    @Autowired
    CartRepository cartRepository;
    
    @Autowired
    OrderRepository orderRepository;
    
    @PostMapping("/add/{id}")
    public String addToCart(@PathVariable Long id){
        Product p = productRepository.findById(id).orElse(null);
        if(p != null) {
           
            Cart cart = cartRepository.findByProduct(p).orElse(null);
            if(cart!=null){
                cart.setQuantity(cart.getQuantity()+1);
            }
            else{
            cart=new Cart();    
            
        cart.setProduct(p);       
        cart.setQuantity(1);
            }
        cartRepository.save(cart);
        }
        return "redirect:/cart";
    }

    @GetMapping("")
public String cart(Model model) {
        

    List<Cart> cartItems = cartRepository.findAll();

    double totalPrice = 0;
        double totalQuantity = 0;

    for (Cart c : cartItems) {
        totalPrice += c.getProduct().getPrice() * c.getQuantity();
        totalQuantity += c.getQuantity();
}

    

    model.addAttribute("cartItems", cartItems);
    model.addAttribute("totalQuantity", totalQuantity);

    model.addAttribute("totalPrice", totalPrice);

    return "cart";
}
    

}