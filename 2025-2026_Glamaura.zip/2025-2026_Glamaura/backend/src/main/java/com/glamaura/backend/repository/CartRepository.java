package com.glamaura.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.glamaura.backend.entity.Cart;
import com.glamaura.backend.entity.Product;
import java.util.List;
import java.util.Optional;


public interface CartRepository extends JpaRepository<Cart, Long> {
    

    Optional<Cart> findByProduct(Product product);
    
}
