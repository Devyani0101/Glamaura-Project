package com.glamaura.backend.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.glamaura.backend.entity.User;
import com.glamaura.backend.repository.UserRepository;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserRepository UserRepository;

    public UserController(UserRepository UserRepository) {
        this.UserRepository = UserRepository;
    }

    
    @PostMapping("/add")
    public User adduser(@RequestBody User user) {
        return UserRepository.save(user);
    }
    @PostMapping("/save")
    public User saveuser(@RequestBody User user) {
        return UserRepository.save(user);
    }


    
    @GetMapping("/all")
    public List<User> getAllUsers() {
        return UserRepository.findAll();
    }
}